package com.supath;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class MyProfileAcitivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile_acitivity);

    }

    public void ima_close(View view) {

        finish();
    }

    public void EditProfile(View view) {

        Intent i=new Intent(getApplicationContext(),EditProfileActivity.class);
        startActivity(i);


    }
}
