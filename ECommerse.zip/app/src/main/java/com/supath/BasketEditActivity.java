package com.supath;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class BasketEditActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[]  Number = { "1", "2", "3", "4", "5"};
Spinner spinner;
String spinnerstrin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basket_edit);

        Spinner spinner = (Spinner) findViewById(R.id.Spinner);

}

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        spinnerstrin=Number[i];

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}