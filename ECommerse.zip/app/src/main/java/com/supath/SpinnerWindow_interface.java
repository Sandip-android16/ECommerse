package com.supath;

public interface SpinnerWindow_interface {


        void selectedPosition(int selected_position);

}
