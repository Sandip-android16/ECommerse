package com.supath.Fragment;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.e_commerse.Model.TopSellersModel;

import com.squareup.picasso.Picasso;
import com.supath.ProductDetailActivity;
import com.supath.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class AllCategoriesFragment extends Fragment {

    ArrayList<TopSellersModel> topSellersModelArrayList = new ArrayList<>();
    RecyclerView top_sellers_list;

    public AllCategoriesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_all_categories, container, false);
        LoadData(v);
        return v;
    }

    private void LoadData(View v) {
        top_sellers_list = v.findViewById(R.id.topsellers_list);

        topSellersModelArrayList.clear();
        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "BetruScatcha", "₹120",true));
        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "ElenRosi", "₹320", false));
        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "AllenMosko", "₹120", true));
        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "Julimeyla", "₹320",false));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2, GridLayoutManager.VERTICAL, false);
        top_sellers_list.setLayoutManager(gridLayoutManager);
        top_sellers_list.setAdapter(new TopSellersListAdapter(getContext(), topSellersModelArrayList));
        top_sellers_list.setNestedScrollingEnabled(false);
        top_sellers_list.setHasFixedSize(true);
//        int height = Constant.GetListViewHeight(getContext(), topSellersModelArrayList.size() / 2, 270) + 80;
//        top_sellers_list.getLayoutParams().height = height;
    }

    public class TopSellersListAdapter extends RecyclerView.Adapter<TopSellersListAdapter.NewViewHolder> {

        Context context;
        ArrayList<TopSellersModel> topSellersModels;

        public TopSellersListAdapter(Context context, ArrayList<TopSellersModel> topSellersModels) {
            this.context = context;
            this.topSellersModels = topSellersModels;
        }

        @NonNull
        @Override
        public TopSellersListAdapter.NewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.top_sellers_list_row, parent, false);
            return new TopSellersListAdapter.NewViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull final TopSellersListAdapter.NewViewHolder holder, final int position) {
            Picasso.with(context).load(topSellersModels.get(position).getImagePath()).into(holder.Image_sellers);
            if (topSellersModels.get(position).isSale()) {
                holder.Sale_Text.setVisibility(View.VISIBLE);
                holder.discount_layout.setVisibility(View.VISIBLE);
            }else {
                holder.Sale_Text.setVisibility(View.GONE);
                holder.discount_layout.setVisibility(View.GONE);
            }
            holder.price_of_item.setText(topSellersModels.get(position).getItem_price());
            holder.sellers_name.setText(topSellersModels.get(position).getSellers_Name());
            holder.Image_sellers.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getContext(),ProductDetailActivity.class);
                    i.putExtra("NAME",topSellersModels.get(position).getSellers_Name());
                    i.putExtra("IMAGE",topSellersModels.get(position).getImagePath());
                    context.startActivity(i);
                }
            });

        }

        @Override
        public int getItemCount() {
            return topSellersModels.size();
        }

        public class NewViewHolder extends RecyclerView.ViewHolder {

            ImageView Image_sellers;
            TextView sellers_name;
            TextView price_of_item;
            TextView Sale_Text;
            ProgressBar progress_bar;
            RelativeLayout discount_layout;

            public NewViewHolder(View itemView) {
                super(itemView);
                progress_bar = itemView.findViewById(R.id.progress_bar);
                Image_sellers = itemView.findViewById(R.id.Sell_Item_Image);
                sellers_name = itemView.findViewById(R.id.seller_name_text);
                price_of_item = itemView.findViewById(R.id.Item_prize_text);
                Sale_Text = itemView.findViewById(R.id.Issale_text);
                discount_layout = itemView.findViewById(R.id.discount_layout);
            }
        }

    }


}
