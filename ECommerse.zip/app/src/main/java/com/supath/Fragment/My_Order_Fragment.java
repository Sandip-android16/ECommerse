package com.supath.Fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.e_commerse.Model.My_Order_List_Model;

import com.squareup.picasso.Picasso;
import com.supath.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the  factory method to
 * create an instance of this fragment.
 */
public class My_Order_Fragment extends Fragment {


    MY_Order_ListAdapter my_order_listAdapter1;

    ArrayList<My_Order_List_Model>listofmodel=new ArrayList<>();
    ListOfOrderAdapter adapter;

    ArrayList<My_Order_List_Model> list_models = new ArrayList<>();
    ListView list_myorder;
    ListView listoforder;
    // Required empty public constructor

    public My_Order_Fragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_my__order_, container, false);


        list_myorder = view.findViewById(R.id.list_my_order);



        list_myorder.setAdapter(new MY_Order_ListAdapter(list_models, getContext()));
        LoadData();
Data();
        return view;
    }

    private void LoadData() {

        My_Order_List_Model model = new My_Order_List_Model("1", "OP16003", "Pleced on Saturday, 20 February 2016", "2", "₹150.00", "", "$80.00", "WHITE Stripe Bomber Jacket", "L", "3 DAYS", "");
        list_models.add(model);
      model = new My_Order_List_Model("1", "OP16003", "Pleced on Saturday, 20 February 2016", "2", "₹750.00", "", "$80.00", "WHITE Stripe Bomber Jacket", "L", "3 DAYS", "");
        list_models.add(model);


    }

    private void Data() {
        My_Order_List_Model model1= new My_Order_List_Model("1", "OP16003", "Pleced on Saturday, 20 February 2016", "1", "₹75.00", "https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "$80.00", "WHITE Stripe Bomber Jacket", "L", "3 DAYS", "Dec 2.2015");
        listofmodel.add(model1);
        model1= new My_Order_List_Model("2", "OP16003", "Pleced on Saturday, 20 February 2016", "2", "₹150.00", "https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "$80.00", "WHITE Stripe Bomber Jacket", "L", "3 DAYS", "Dec 2.2015");
        listofmodel.add(model1);
        model1= new My_Order_List_Model("3", "OP16003", "Pleced on Saturday, 20 February 2016", "2", "₹150.00", "https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "$80.00", "WHITE Stripe Bomber Jacket", "L", "3 DAYS", "Dec 2.2015");
        listofmodel.add(model1);


    }


    public class MY_Order_ListAdapter extends BaseAdapter {

        ArrayList<My_Order_List_Model> list;
        Context context;

        public MY_Order_ListAdapter(ArrayList<My_Order_List_Model> list, Context context) {
            this.list = list;
            this.context = context;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return list.get(i);
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup parent) {


            if (view == null) {

                view = LayoutInflater.from(context).inflate(R.layout.my_order_list_rows, parent, false);

            }

            TextView txt_orderno, txt_order_date, txt_item_count, txt_total, txt_asos, txt_order_name, txt_size, txt_duration, txt_delivry;
          //  ImageView ima_order;
            LinearLayout lin_top;
          //  ima_order = view.findViewById(R.id.ima_order);
            lin_top = view.findViewById(R.id.lin_top);
            txt_orderno = view.findViewById(R.id.txt_orderno);
            txt_order_date = view.findViewById(R.id.txt_order_date);
            txt_item_count = view.findViewById(R.id.txt_item_count);
            txt_total = view.findViewById(R.id.txt_total);
//            txt_asos = view.findViewById(R.id.txt_asos);
//            ima_order = view.findViewById(R.id.ima_order);
//            txt_order_name = view.findViewById(R.id.txt_order_name);
//            txt_size = view.findViewById(R.id.txt_size);
//            txt_duration = view.findViewById(R.id.txt_duration);
//            txt_delivry = view.findViewById(R.id.txt_delivry);

                listoforder=view.findViewById(R.id.listoforder);
               // Data();
                if (list_models.get(i).getId().equals("")){


                }else
                {
                    listoforder.setAdapter(new ListOfOrderAdapter(listofmodel,getContext()));
                }


            txt_orderno.setText(list.get(i).getOrder_NO());
            txt_order_date.setText(list.get(i).getOrder_Date());
            txt_item_count.setText(list.get(i).getOrder_Item());
            txt_total.setText(list.get(i).getOrder_Total());
        //  Picasso.with(context).load(list.get(i).getOrder_Image()).into(ima_order);
            return view;
        }


    }



    public class ListOfOrderAdapter extends BaseAdapter{

        ArrayList<My_Order_List_Model>modelArrayList;
        Context context;

        public ListOfOrderAdapter(ArrayList<My_Order_List_Model> modelArrayList, Context context) {
            this.modelArrayList = modelArrayList;
            this.context = context;
        }

        @Override
        public int getCount() {
            return modelArrayList.size();
        }

        @Override
        public Object getItem(int i) {
            return modelArrayList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

          if (view == null){

              view=LayoutInflater.from(context).inflate(R.layout.myorder_list_row1,viewGroup,false);
          }

            TextView txt_orderno, txt_order_date, txt_item_count, txt_total, txt_asos, txt_order_name, txt_size, txt_duration, txt_delivry;
              ImageView ima_order,ima_order1;
            LinearLayout lin_top;
              ima_order = view.findViewById(R.id.ima_order);
              ima_order1 = view.findViewById(R.id.ima_order1);
            lin_top = view.findViewById(R.id.lin_top);
//            txt_orderno = view.findViewById(R.id.txt_orderno);
//            txt_order_date = view.findViewById(R.id.txt_order_date);
//            txt_item_count = view.findViewById(R.id.txt_item_count);
//            txt_total = view.findViewById(R.id.txt_total);
//            txt_asos = view.findViewById(R.id.txt_asos);

            txt_order_name = view.findViewById(R.id.txt_order_name);
            txt_size = view.findViewById(R.id.txt_size);
            txt_duration = view.findViewById(R.id.txt_duration);
            txt_delivry = view.findViewById(R.id.txt_delivry);


//
//            txt_orderno.setText(list.get(i).getOrder_NO());
//            txt_order_date.setText(list.get(i).getOrder_Date());
//            txt_item_count.setText(list.get(i).getOrder_Item());
//            txt_total.setText(list.get(i).getOrder_Total());
              Picasso.with(context).load(modelArrayList.get(i).getOrder_Image()).into(ima_order);
              Picasso.with(context).load(modelArrayList.get(i).getOrder_Image()).into(ima_order1);

           return view;
        }
    }




}
