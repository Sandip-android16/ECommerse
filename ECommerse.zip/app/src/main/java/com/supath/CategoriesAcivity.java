package com.supath;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class CategoriesAcivity extends AppCompatActivity {
    LinearLayout lin_navigation_menu_basket,lin_navigation_menu_myorders,lin_allcategories,lin_home;
    ImageView img_nav_close;
    ListView listcategories;
    CategoriesAdapter categoriesAdapter;
    ArrayList<com.supath.CategoriesModel>categoriesModels=new ArrayList<>();
    CircleImageView ima_profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories_acivity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_close_white_24dp);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });




        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);


        ima_profile=findViewById(R.id.ima_profile);

        ima_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(CategoriesAcivity.this,MyProfileAcitivity.class);
                startActivity(intent);
            }
        });

        lin_home=findViewById(R.id.lin_home);
        lin_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i=new Intent(getApplicationContext(),WelcomeActivity.class);
                startActivity(i);
                finish();
            }
        });

        img_nav_close=findViewById(R.id.img_nav);
        img_nav_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        lin_navigation_menu_basket = findViewById(R.id.lin_navigation_menu_basket);
        lin_navigation_menu_basket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),BasketActivity.class);
                startActivity(i);
            }
        });

        lin_navigation_menu_myorders = findViewById(R.id.lin_navigation_menu_myorders);

        lin_navigation_menu_myorders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),MyOrderActivity.class);
                startActivity(i);
            }
        });

        listcategories=findViewById(R.id.list_categories);

        Data();

listcategories.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        Intent intent=new Intent(getApplicationContext(),AllCategoriesActivity.class);
        startActivity(intent);
    }
});
    }



    public void Data(){

        com.supath.CategoriesModel model=new com.supath.CategoriesModel("https://ae01.alicdn.com/kf/HTB1ImsaKVXXXXX1XXXXq6xXFXXXh/2016-Autumn-Plus-Size-Men-Blazer-Fashion-Slim-Casual-Blazer-for-Men-Brand-Mens-Suit-Designer.jpg_640x640.jpg", "Beatsellers");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("http://www.littlestepsasia.com/sites/default/files/imagecache/article_node_image/article/hero/Maternity-Exchange.jpg", "Women");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("http://masterlyweft.com/media/wysiwyg/images/home_3/dolce-and-gabbana-dg-spring-summer-2016-collection-man-clothing-shoes-luxury-sportswear-gentleman-shop-online-store-2400x784-banner-landing-desktop.jpg","Men");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("https://images.indianexpress.com/2017/10/kids-fashion_759_ts.jpg","Kids");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("http://www.amarphonebook.com/largeImage/1455972043.jpg","Sports");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("http://mycochin.in/wp-content/uploads/2017/07/mob-accessories-banner-1-1140x380.png","Accessories");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("https://upload.wikimedia.org/wikipedia/commons/5/55/Adidas_sneakers_display_-_several_left_shoes.jpg","Footwear");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("https://indiantheme.files.wordpress.com/2015/06/baaya-design-diwali-lamps-for-sale-best-home-dc3a9cor-items.jpg","Home");
        categoriesModels.add(model);
        model=new com.supath.CategoriesModel("https://static2.fashionbeans.com/wp-content/uploads/2016/04/luxuryfashion2.jpg","Luxury");
        categoriesModels.add(model);

        listcategories.setAdapter(new CategoriesAdapter(categoriesModels,CategoriesAcivity.this));

    }


    public class CategoriesAdapter extends BaseAdapter{


        ArrayList<com.supath.CategoriesModel>list=new ArrayList<>();
        Context context;

        public CategoriesAdapter(ArrayList<com.supath.CategoriesModel> list, Context context) {
            this.list = list;
            this.context = context;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return list.get(i);
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {



            if (view == null){

                view= LayoutInflater.from(context).inflate(R.layout.categories_row,viewGroup,false);
            }

            TextView Item_Text=view.findViewById(R.id.Item_Text);
            ImageView image_cat=view.findViewById(R.id.image_cat);


            Item_Text.setText(list.get(i).getName());
            Picasso.with(context).load(list.get(i).getImagePath()).into(image_cat);


            return view;
        }
    }




    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


}
