package com.supath;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.squareup.picasso.Picasso;

public class ProductDetailActivity extends AppCompatActivity {

    ImageView img_product_image;

    RelativeLayout rel_Choose_Size_Box,rel_Choose_Color_Box;
    LinearLayout lin_choose_color,lin_choose_size;
    ImageView img_choose_color_arrow,img_choose_size_arrow;

    LinearLayout lin_purchase_layout;

    boolean IsColorLayoutExpanded = false;
    boolean IsSizeLayoutExpanded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        Toolbar toolbar =  findViewById(R.id.toolbar);
        toolbar.setTitle(getIntent().getStringExtra("NAME"));
        setSupportActionBar(toolbar);
        img_product_image = findViewById(R.id.img_product_image);
        Picasso.with(ProductDetailActivity.this).load(getIntent().getStringExtra("IMAGE")).into(img_product_image);

        lin_purchase_layout = findViewById(R.id.lin_purchase_layout);

        rel_Choose_Size_Box = findViewById(R.id.rel_Choose_Size_Box);
        rel_Choose_Color_Box = findViewById(R.id.rel_Choose_Color_Box);
        lin_choose_color = findViewById(R.id.lin_choose_color);
        lin_choose_size = findViewById(R.id.lin_choose_size);
        img_choose_color_arrow = findViewById(R.id.img_choose_color_arrow);
        img_choose_size_arrow = findViewById(R.id.img_choose_size_arrow);

        lin_choose_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (IsColorLayoutExpanded){
                    rel_Choose_Color_Box.setVisibility(View.GONE);
                    img_choose_color_arrow.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                    IsColorLayoutExpanded = false;
                }else {
                    img_choose_color_arrow.setImageResource(R.drawable.ic_expand_less_black_24dp);
                    rel_Choose_Color_Box.setVisibility(View.VISIBLE);
                    IsColorLayoutExpanded = true;
                    rel_Choose_Size_Box.setVisibility(View.GONE);
                    img_choose_size_arrow.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                    IsSizeLayoutExpanded = false;
                }
            }
        });

        lin_choose_size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (IsSizeLayoutExpanded){
                    rel_Choose_Size_Box.setVisibility(View.GONE);
                    img_choose_size_arrow.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                    IsSizeLayoutExpanded = false;
                }else {
                    img_choose_size_arrow.setImageResource(R.drawable.ic_expand_less_black_24dp);
                    rel_Choose_Size_Box.setVisibility(View.VISIBLE);
                    IsSizeLayoutExpanded = true;
                    rel_Choose_Color_Box.setVisibility(View.GONE);
                    img_choose_color_arrow.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                    IsColorLayoutExpanded = false;
                }
            }
        });

        lin_purchase_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ProductDetailActivity.this,BasketActivity.class));
            }
        });

    }

    public void finish_actiity(View view) {
        finish();
    }
}
