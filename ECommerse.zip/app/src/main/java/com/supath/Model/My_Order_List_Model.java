package com.e_commerse.Model;

public class My_Order_List_Model {

    private String Id;
    private String Order_NO;
    private String Order_Date;
    private String Order_Item;
    private String Order_Total;
    private String Order_Image;
    private String Order_asos_name;
    private String Order_detali;
    private String Order_Size;
    private String Order_duration;
    private String Order_delivery;

    public My_Order_List_Model(String id, String order_NO, String order_Date, String order_Item, String order_Total, String order_Image, String order_asos_name, String order_detali, String order_Size, String order_duration, String order_delivery) {
        Id = id;
        Order_NO = order_NO;
        Order_Date = order_Date;
        Order_Item = order_Item;
        Order_Total = order_Total;
        Order_Image = order_Image;
        Order_asos_name = order_asos_name;
        Order_detali = order_detali;
        Order_Size = order_Size;
        Order_duration = order_duration;
        Order_delivery = order_delivery;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getOrder_NO() {
        return Order_NO;
    }

    public void setOrder_NO(String order_NO) {
        Order_NO = order_NO;
    }

    public String getOrder_Date() {
        return Order_Date;
    }

    public void setOrder_Date(String order_Date) {
        Order_Date = order_Date;
    }

    public String getOrder_Item() {
        return Order_Item;
    }

    public void setOrder_Item(String order_Item) {
        Order_Item = order_Item;
    }

    public String getOrder_Total() {
        return Order_Total;
    }

    public void setOrder_Total(String order_Total) {
        Order_Total = order_Total;
    }

    public String getOrder_Image() {
        return Order_Image;
    }

    public void setOrder_Image(String order_Image) {
        Order_Image = order_Image;
    }

    public String getOrder_asos_name() {
        return Order_asos_name;
    }

    public void setOrder_asos_name(String order_asos_name) {
        Order_asos_name = order_asos_name;
    }

    public String getOrder_detali() {
        return Order_detali;
    }

    public void setOrder_detali(String order_detali) {
        Order_detali = order_detali;
    }

    public String getOrder_Size() {
        return Order_Size;
    }

    public void setOrder_Size(String order_Size) {
        Order_Size = order_Size;
    }

    public String getOrder_duration() {
        return Order_duration;
    }

    public void setOrder_duration(String order_duration) {
        Order_duration = order_duration;
    }

    public String getOrder_delivery() {
        return Order_delivery;
    }

    public void setOrder_delivery(String order_delivery) {
        Order_delivery = order_delivery;
    }
}
