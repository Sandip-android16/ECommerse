package com.supath;

public class CategoriesModel {


    private String imagePath;
    private String name;

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CategoriesModel(String imagePath, String name) {

        this.imagePath = imagePath;
        this.name = name;
    }
}
