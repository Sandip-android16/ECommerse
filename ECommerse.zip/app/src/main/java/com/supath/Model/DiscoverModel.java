package com.e_commerse.Model;

public class DiscoverModel {
    int imagePath;
    String text;

    public DiscoverModel(int imagePath, String text) {
        this.imagePath = imagePath;
        this.text = text;
    }

    public int getImagePath() {
        return imagePath;
    }

    public void setImagePath(int imagePath) {
        this.imagePath = imagePath;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
