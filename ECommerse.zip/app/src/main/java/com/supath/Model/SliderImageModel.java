package com.e_commerse.Model;

public class SliderImageModel {
    String image_link;

    public SliderImageModel(String image_link) {
        this.image_link = image_link;
    }

    public String getImage_link() {
        return image_link;
    }

    public void setImage_link(String image_link) {
        this.image_link = image_link;
    }
}
