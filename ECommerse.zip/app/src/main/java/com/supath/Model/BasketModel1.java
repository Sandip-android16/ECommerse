package com.supath.Model;

public class BasketModel1 {


    private String Basket_ima;
    private String Basket_no;
    private String Basket_name;

    public BasketModel1(String basket_ima, String basket_no, String basket_name) {
        Basket_ima = basket_ima;
        Basket_no = basket_no;
        Basket_name = basket_name;
    }

    public String getBasket_ima() {
        return Basket_ima;
    }

    public void setBasket_ima(String basket_ima) {
        Basket_ima = basket_ima;
    }

    public String getBasket_no() {
        return Basket_no;
    }

    public void setBasket_no(String basket_no) {
        Basket_no = basket_no;
    }

    public String getBasket_name() {
        return Basket_name;
    }

    public void setBasket_name(String basket_name) {
        Basket_name = basket_name;
    }
}
