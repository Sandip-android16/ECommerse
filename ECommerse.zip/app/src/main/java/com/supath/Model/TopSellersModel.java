package com.e_commerse.Model;

public class TopSellersModel {
    String ImagePath;
    String Sellers_Name;
    String Item_price;
    boolean IsSale;

    public TopSellersModel(String imagePath, String sellers_Name, String item_price, boolean isSale) {
        ImagePath = imagePath;
        Sellers_Name = sellers_Name;
        Item_price = item_price;
        IsSale = isSale;
    }

    public String getImagePath() {
        return ImagePath;
    }

    public void setImagePath(String imagePath) {
        ImagePath = imagePath;
    }

    public String getSellers_Name() {
        return Sellers_Name;
    }

    public void setSellers_Name(String sellers_Name) {
        Sellers_Name = sellers_Name;
    }

    public String getItem_price() {
        return Item_price;
    }

    public void setItem_price(String item_price) {
        Item_price = item_price;
    }

    public boolean isSale() {
        return IsSale;
    }

    public void setSale(boolean sale) {
        IsSale = sale;
    }
}
