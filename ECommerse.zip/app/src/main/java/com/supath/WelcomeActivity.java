package com.supath;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.TextView;

import com.e_commerse.Adapter.SliderImageAdapter;
import com.e_commerse.Model.DiscoverModel;
import com.e_commerse.Model.SliderImageModel;
import com.e_commerse.Model.TopSellersModel;
import com.e_commerse.Utils.Constant;
import com.infideap.drawerbehavior.Advance3DDrawerLayout;
import com.squareup.picasso.Picasso;
import com.supath.BasketActivity;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class WelcomeActivity extends AppCompatActivity{

    // implements NavigationView.OnNavigationItemSelectedListener
    TextView txt_name;
    int i=0;
    EditText txt_serch;
    ImageView img_nav_close;
    LinearLayout lin_navigation_menu_basket,lin_navigation_menu_myorders,lin_allcategories;
    ViewPager viewPager_welcome;
    RecyclerView top_sellers_list;
    RecyclerView discover_catgroy_list;
    private Handler handler;
    String TAG = "WelcomeActivity";
    private int currentPage;
    private Timer timer;
    final long DELAY_MS = 500;//delay in milliseconds before task is to be executed
    final long PERIOD_MS = 3000; // time in milliseconds between successive task executions.
    RelativeLayout rel_top;
    SearchView searchView;
    ImageView ima_SearchView;
    ArrayList<SliderImageModel> sliderImageModelArrayList = new ArrayList<>();
    ArrayList<TopSellersModel> topSellersModelArrayList = new ArrayList<>();
    ArrayList<DiscoverModel> discoverModelArrayList = new ArrayList<>();
    CircleImageView ima_profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_3d);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);


        viewPager_welcome = findViewById(R.id.welcome_sale_viewpager);
        top_sellers_list = findViewById(R.id.topsellers_list);
        discover_catgroy_list = findViewById(R.id.catgroy_list);

        top_sellers_list.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

                Intent i=new Intent(WelcomeActivity.this,AllCategoriesActivity.class);
                startActivity(i);

                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView rv, MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });


        img_nav_close=findViewById(R.id.img_nav);
        img_nav_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        lin_navigation_menu_basket = findViewById(R.id.lin_navigation_menu_basket);
        lin_navigation_menu_basket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),BasketActivity.class);
                startActivity(i);
            }
        });
        lin_allcategories=findViewById(R.id.lin_allcategories);
        lin_allcategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),CategoriesAcivity.class);
                startActivity(i);
            }
        });

        ima_profile=findViewById(R.id.ima_profile);

        ima_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(WelcomeActivity.this,MyProfileAcitivity.class);
                startActivity(intent);
            }
        });

        rel_top=findViewById(R.id.rel_top);
        txt_name=findViewById(R.id.txt_name);
        txt_serch=findViewById(R.id.txt_serch);
        ima_SearchView=findViewById(R.id.ima_SearchView);


        txt_name.setVisibility(View.VISIBLE);

        ima_SearchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (i == 0){
                    txt_serch.setVisibility(View.VISIBLE);
                    txt_name.setVisibility(View.GONE);
                    i=1;
                }
                else if (i == 1){
                    txt_serch.setVisibility(View.GONE);
                    txt_name.setVisibility(View.VISIBLE);
                    i=0;

                }


            }
        });

        lin_navigation_menu_myorders = findViewById(R.id.lin_navigation_menu_myorders);

        lin_navigation_menu_myorders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),MyOrderActivity.class);
                startActivity(i);
            }
        });
        sliderImageModelArrayList.add(new SliderImageModel("https://trickygyan.in/wp-content/uploads/2018/05/Amazon-Fashion-Sale-1024x394.png"));
        sliderImageModelArrayList.add(new SliderImageModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROUiKLR6QHtprHkCQgORfpQS1toKuBMuxtUm2k2cqNVKnV_iof"));
        sliderImageModelArrayList.add(new SliderImageModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIPGnJ4h__8MvzuCoyiKDeStAaWhwm9Lw1Ql21QJ07v9s75ZZu"));
        sliderImageModelArrayList.add(new SliderImageModel("http://www.couponcandy.in/wp-content/uploads/2015/07/men-clothing.jpg"));
        viewPager_welcome.setAdapter(new SliderImageAdapter(WelcomeActivity.this, sliderImageModelArrayList));

        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "BetruScatcha", "₹120",true));
        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "ElenRosi", "₹320", false));
        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "AllenMosko", "₹120", true));
        topSellersModelArrayList.add(new TopSellersModel("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg", "Julimeyla", "₹320",false));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(WelcomeActivity.this, 2, GridLayoutManager.VERTICAL, false);
        top_sellers_list.setLayoutManager(gridLayoutManager);
        top_sellers_list.setAdapter(new TopSellersListAdapter(WelcomeActivity.this, topSellersModelArrayList));
        top_sellers_list.setNestedScrollingEnabled(false);
        top_sellers_list.setHasFixedSize(true);
        int height = Constant.GetListViewHeight(WelcomeActivity.this, topSellersModelArrayList.size() / 2, 270) + 80;
        top_sellers_list.getLayoutParams().height = height;

        discoverModelArrayList.add(new DiscoverModel(R.drawable.dresses_image, "Dresses"));
        discoverModelArrayList.add(new DiscoverModel(R.drawable.shorts_image, "Shorts"));
        discoverModelArrayList.add(new DiscoverModel(R.drawable.shoses_image, "Shoes"));

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(WelcomeActivity.this, LinearLayoutManager.VERTICAL, false);
        discover_catgroy_list.setLayoutManager(linearLayoutManager);
        discover_catgroy_list.setAdapter(new DisCoverCategory(WelcomeActivity.this, discoverModelArrayList));
        discover_catgroy_list.setNestedScrollingEnabled(false);
        discover_catgroy_list.setHasFixedSize(true);
        discover_catgroy_list.getLayoutParams().height = Constant.GetListViewHeight(WelcomeActivity.this, discoverModelArrayList.size(), 150);
        ScrollView scrollView = findViewById(R.id.main_scroll);
        scrollView.smoothScrollTo(0, 0);



    }

    @Override
    protected void onPause() {
        super.onPause();
        timer.cancel();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Auto Scroll
        handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == sliderImageModelArrayList.size() - 1) {
                    currentPage = 0;
                    Log.d(TAG, "run: " + "Is Viewpager Count Now 0");
                }
                viewPager_welcome.setCurrentItem(currentPage++, true);
            }
        };
        timer = new Timer(); // This will create a new Thread
        timer.schedule(new TimerTask() { // task to be scheduled
            @Override
            public void run() {
                handler.post(Update);
                Log.d(TAG, "run: " + "Handler Post....");
            }
        }, DELAY_MS, PERIOD_MS);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_3d);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //Adapter

    public class TopSellersListAdapter extends RecyclerView.Adapter<TopSellersListAdapter.NewViewHolder> {

        Context context;
        ArrayList<TopSellersModel> topSellersModels;

        public TopSellersListAdapter(Context context, ArrayList<TopSellersModel> topSellersModels) {
            this.context = context;
            this.topSellersModels = topSellersModels;
        }

        @NonNull
        @Override
        public TopSellersListAdapter.NewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.top_sellers_list_row, parent, false);
            return new NewViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull final NewViewHolder holder, final int position) {
            Picasso.with(context).load(topSellersModels.get(position).getImagePath()).into(holder.Image);
            if (topSellersModels.get(position).isSale()) {
                holder.Sale_Text.setVisibility(View.VISIBLE);
                holder.discount_layout.setVisibility(View.VISIBLE);
            }else {
                holder.Sale_Text.setVisibility(View.GONE);
                holder.discount_layout.setVisibility(View.GONE);
            }
            holder.price_of_item.setText(topSellersModels.get(position).getItem_price());
            holder.sellers_name.setText(topSellersModels.get(position).getSellers_Name());
            holder.Image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context,ProductDetailActivity.class);
                    i.putExtra("NAME",String.valueOf(topSellersModels.get(position).getSellers_Name()));
                    i.putExtra("IMAGE",String.valueOf(topSellersModels.get(position).getImagePath()));
                    startActivity(i);
                }
            });

        }

        @Override
        public int getItemCount() {
            return topSellersModels.size();
        }

        public class NewViewHolder extends RecyclerView.ViewHolder {

            ImageView Image;
            TextView sellers_name;
            TextView price_of_item;
            TextView Sale_Text;
            ProgressBar progress_bar;
            RelativeLayout discount_layout;

            public NewViewHolder(View itemView) {
                super(itemView);
                progress_bar = itemView.findViewById(R.id.progress_bar);
                Image = itemView.findViewById(R.id.Sell_Item_Image);
                sellers_name = itemView.findViewById(R.id.seller_name_text);
                price_of_item = itemView.findViewById(R.id.Item_prize_text);
                Sale_Text = itemView.findViewById(R.id.Issale_text);
                discount_layout = itemView.findViewById(R.id.discount_layout);
            }
        }

    }

    public class DisCoverCategory extends RecyclerView.Adapter<DisCoverCategory.ViewHolder> {

        Context context;
        ArrayList<DiscoverModel> discoverModels;

        public DisCoverCategory(Context context, ArrayList<DiscoverModel> discoverModels) {
            this.context = context;
            this.discoverModels = discoverModels;
        }

        @NonNull
        @Override
        public DisCoverCategory.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.descover_catgroy_list_row, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Picasso.with(context).load(discoverModels.get(position).getImagePath()).into(holder.Item_Image);
            holder.Item_Text.setText(discoverModels.get(position).getText());
//            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    startActivity(new Intent(WelcomeActivity.this,AllCategoriesActivity.class));
//                }
//            });
        }

        @Override
        public int getItemCount() {
            return discoverModels.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            ImageView Item_Image;
            TextView Item_Text;

            public ViewHolder(View itemView) {
                super(itemView);
                Item_Image = itemView.findViewById(R.id.image_cat);
                Item_Text = itemView.findViewById(R.id.Item_Text);
            }
        }

    }


}
