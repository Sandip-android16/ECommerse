package com.e_commerse.Utils;

import android.content.Context;

public class Constant {

    public static int dpToPx(Context context,int dp) {
        float density = context.getResources()
                .getDisplayMetrics()
                .density;
        return Math.round((float) dp * density);
    }

    public static int GetListViewHeight(Context context,int Count,int Dp){
        return (Constant.dpToPx(context,Dp) * Count);
    }

}
