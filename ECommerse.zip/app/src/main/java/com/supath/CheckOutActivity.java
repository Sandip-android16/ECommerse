package com.supath;

import android.graphics.Color;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.e_commerse.Adapter.ViewPagerAdapter;

import com.supath.Fragment.AddressFragment;
import com.supath.Fragment.PaymentFragment;
import com.supath.Fragment.ShippingFragment;
import com.supath.R;

public class CheckOutActivity extends AppCompatActivity {

    ViewPagerAdapter viewPagerAdapter;
    ViewPager viewpager_check_out;
    TabLayout tabLayout_check_out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_close_white_24dp);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        viewpager_check_out = findViewById(R.id.ViewPager_check_out);
        tabLayout_check_out = findViewById(R.id.tablayout_check_out);
        tabLayout_check_out.setTabTextColors(getResources().getColor(R.color.colorPrimaryDark), Color.WHITE);

        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new AddressFragment(),"Address");
        viewPagerAdapter.addFragment(new ShippingFragment(),"Shipping");
        viewPagerAdapter.addFragment(new PaymentFragment(),"Payment");

        viewpager_check_out.setAdapter(viewPagerAdapter);

        tabLayout_check_out.setupWithViewPager(viewpager_check_out);

    }
}
