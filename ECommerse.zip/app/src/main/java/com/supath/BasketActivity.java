package com.supath;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;


import com.squareup.picasso.Picasso;
import com.supath.Model.BasketModel1;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class BasketActivity extends AppCompatActivity {
    LinearLayout lin_navigation_menu_basket,lin_navigation_menu_myorders,lin_allcategories,lin_home;
    ImageView img_nav_close;
    RelativeLayout goto_checkout;
    BasketAdapter basketAdapter;
    ArrayList<BasketModel1>basketModels=new ArrayList<>();
    ListView listBasket;
    CircleImageView ima_profile;
    Button spinner;

//    private static SpinnerWindow_interface spinnerWindow_interface;
//
//    public BasketActivity(SpinnerWindow_interface spinnerWindow_interface)
//    {
//        BasketActivity.spinnerWindow_interface = spinnerWindow_interface;
//    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basket);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);





        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);

        ima_profile=findViewById(R.id.ima_profile);

        ima_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(BasketActivity.this,MyProfileAcitivity.class);
                startActivity(intent);
            }
        });


        img_nav_close=findViewById(R.id.img_nav);
        img_nav_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        lin_navigation_menu_basket = findViewById(R.id.lin_navigation_menu_basket);
        lin_navigation_menu_basket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),BasketActivity.class);
                startActivity(i);
            }
        });

        lin_navigation_menu_myorders = findViewById(R.id.lin_navigation_menu_myorders);

        lin_navigation_menu_myorders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MyOrderActivity.class);
                startActivity(i);
            }
        });

        lin_home=findViewById(R.id.lin_home);
        lin_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i=new Intent(getApplicationContext(), WelcomeActivity.class);
                startActivity(i);
                finish();
            }
        });

        lin_allcategories=findViewById(R.id.lin_allcategories);
        lin_allcategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), CategoriesAcivity.class);
                startActivity(i);
            }
        });


        goto_checkout=findViewById(R.id.goto_checkout);
        goto_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), CheckOutActivity.class);
                startActivity(i);
            }
        });




        listBasket=findViewById(R.id.listbasket);
        Data();
    }


    public void Data(){

        BasketModel1 model=new BasketModel1("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg","₹200","Dress helena");
        basketModels.add(model);
        model=new BasketModel1("https://i.pinimg.com/originals/46/07/77/460777ba9abfe06a46a92ccd690b0bdc.jpg","₹100","Dress helena");
        basketModels.add(model);
        listBasket.setAdapter(new BasketAdapter(basketModels,BasketActivity.this));


    }



    public class BasketAdapter extends BaseAdapter{

ArrayList<BasketModel1>list;
Context context;

        public BasketAdapter(ArrayList<BasketModel1> list, Context context) {
            this.list = list;
            this.context = context;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return list.get(i);
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            if (view == null){
                view=LayoutInflater.from(context).inflate(R.layout.basket_row,viewGroup,false);
            }


            TextView txt_name,txt_no;
            ImageView basket_ima,img_edit_basket,ima_delete;

            txt_name=view.findViewById(R.id.txt_name);
            txt_no=view.findViewById(R.id.txt_no);
            basket_ima=view.findViewById(R.id.basket_ima);
            img_edit_basket=view.findViewById(R.id.img_edit_basket);
            ima_delete=view.findViewById(R.id.ima_delete);
            spinner=view.findViewById(R.id.spinner);



            spinner.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    showSpinner();
                }
            });







//            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(BasketActivity.this,android.R.layout.simple_dropdown_item_1line,counts);
//            spinner.setAdapter(arrayAdapter);

            ima_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final Dialog dialog = new Dialog(BasketActivity.this);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setCancelable(false);
                    dialog.setContentView(R.layout.custom_delete_confirmation_dialog);
                    Button btn_dilog_delete=dialog.findViewById(R.id.btn_dilog_delete);
                    Button btn_dilog_ok=dialog.findViewById(R.id.btn_dilog_ok);
                    final LinearLayout lin_dilog1=dialog.findViewById(R.id.lin_dilog1);
                    final LinearLayout lin_dialog2=dialog.findViewById(R.id.lin_dialog2);

                    lin_dilog1.setVisibility(View.VISIBLE);
                    lin_dialog2.setVisibility(View.GONE);
                    dialog.show();
                    btn_dilog_delete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            lin_dilog1.setVisibility(View.GONE);
                            lin_dialog2.setVisibility(View.VISIBLE);
                        }
                    });

                    btn_dilog_ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            dialog.dismiss();
                        }
                    });



                }

            });



            img_edit_basket.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(BasketActivity.this, BasketEditActivity.class));

                }
            });

            txt_name.setText(list.get(i).getBasket_name());
            txt_no.setText(list.get(i).getBasket_no());

            Picasso.with(context).load(list.get(i).getBasket_ima()).into(basket_ima);


            return view;
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    public void showSpinner()
    {
        final Dialog dialog_spinner = new Dialog(BasketActivity.this);

        dialog_spinner.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog_spinner.setContentView(R.layout.spinner_dialog);

        WindowManager.LayoutParams lp_number_picker = new WindowManager.LayoutParams();
        Window window = dialog_spinner.getWindow();
        lp_number_picker.copyFrom(window.getAttributes());

        lp_number_picker.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp_number_picker.height = WindowManager.LayoutParams.WRAP_CONTENT;

        window.setGravity(Gravity.BOTTOM);
        window.setAttributes(lp_number_picker);

        dialog_spinner.getWindow().setGravity(Gravity.BOTTOM);

        dialog_spinner.getWindow().getAttributes().windowAnimations = R.style.custom_alert_dialog_animation_spinner;

        ListView listview_spinner = (ListView) dialog_spinner.findViewById(R.id.listview_spinner);
        final ArrayList<String> counts= new ArrayList<>();
        counts.add("1");
        counts.add("2");
        counts.add("3");
        counts.add("4");
        counts.add("5");


        listview_spinner.setAdapter(new ArrayAdapter<String>(BasketActivity.this, R.layout.spinner_textview, R.id.number_textview, counts));

        listview_spinner.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
               // spinnerWindow_interface.selectedPosition(position);
                spinner.setText(counts.get(position));
                if(dialog_spinner != null)
                {
                    dialog_spinner.dismiss();
                    dialog_spinner.cancel();
                }
            }
        });


        dialog_spinner.show();
    }



}
