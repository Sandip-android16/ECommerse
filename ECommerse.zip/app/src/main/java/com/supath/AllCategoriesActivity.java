package com.supath;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.internal.NavigationMenu;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;

import com.e_commerse.Adapter.ViewPagerAdapter;

import com.supath.Fragment.AllCategoriesFragment;
import com.supath.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class AllCategoriesActivity extends AppCompatActivity {

    //implements NavigationView.OnNavigationItemSelectedListener

    LinearLayout lin_navigation_menu_basket,lin_navigation_menu_myorders,lin_allcategories,lin_home;
    TabLayout tabLayout;
    ViewPager viewPager;
    ImageView img_nav_close;
    RelativeLayout rel_top;
    EditText txt_serch;
    ImageView ima_SearchView;
    TextView txt_name;
    CircleImageView ima_profile;
    int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_categories);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);

        img_nav_close=findViewById(R.id.img_nav);
        img_nav_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        lin_navigation_menu_basket = findViewById(R.id.lin_navigation_menu_basket);

        lin_navigation_menu_myorders = findViewById(R.id.lin_navigation_menu_myorders);

        lin_navigation_menu_myorders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),MyOrderActivity.class);
                startActivity(i);
            }
        });

        lin_home=findViewById(R.id.lin_home);
        lin_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i=new Intent(getApplicationContext(),WelcomeActivity.class);
                startActivity(i);
                finish();
            }
        });

        lin_allcategories=findViewById(R.id.lin_allcategories);
        lin_allcategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),CategoriesAcivity.class);
                startActivity(i);
            }
        });
        ima_profile=findViewById(R.id.ima_profile);

        ima_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(AllCategoriesActivity.this,MyProfileAcitivity.class);
                startActivity(intent);
            }
        });

        rel_top=findViewById(R.id.rel_top);
        txt_name=findViewById(R.id.txt_name);
        txt_serch=findViewById(R.id.txt_serch);
        ima_SearchView=findViewById(R.id.ima_SearchView);


        txt_name.setVisibility(View.VISIBLE);

        ima_SearchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (i == 0){
                    txt_serch.setVisibility(View.VISIBLE);
                    txt_name.setVisibility(View.GONE);
                    i=1;
                }
                else if (i == 1){
                    txt_serch.setVisibility(View.GONE);
                    txt_name.setVisibility(View.VISIBLE);
                    i=0;

                }


            }
        });

        lin_navigation_menu_basket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),BasketActivity.class);
                startActivity(i);
            }
        });

        tabLayout = findViewById(R.id.tablayout_all_categori);
        tabLayout.setTabTextColors(getResources().getColor(R.color.colorPrimaryDark),Color.WHITE);
        tabLayout.setTabGravity(Gravity.FILL);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
       viewPager = findViewById(R.id.ViewPager_All_Categories);

        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new AllCategoriesFragment(),"Dresses");
        viewPagerAdapter.addFragment(new AllCategoriesFragment(),"Jens");
        viewPagerAdapter.addFragment(new AllCategoriesFragment(),"Suits");
        viewPagerAdapter.addFragment(new AllCategoriesFragment(),"Dresses");

        viewPager.setAdapter(viewPagerAdapter);

        tabLayout.setupWithViewPager(viewPager);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

}